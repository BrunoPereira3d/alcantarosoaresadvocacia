# Pendências de reconstrução

- [x] Verificar informações públicas dos perfis oficiais e registrar somente dados confirmados.
- [x] Preparar e hospedar os logotipos, retrato e imagens fornecidas como assets estáticos do projeto.
- [x] Elaborar textos institucionais sem alegações, resultados ou informações não confirmadas.
- [x] Implementar a página institucional responsiva, incluindo SEO e prévia de compartilhamento.
- [x] Validar conteúdo, experiência visual e acessibilidade em desktop e mobile.
- [x] Criar o repositório público `alcantarosoaresadvocacia` e verificar o envio do pacote completo de continuidade.
- [x] Remover o trilho vertical que acompanha a numeração das seções.
- [x] Adicionar botão flutuante de contato via WhatsApp com mensagem automática.
- [x] Inserir endereço completo e link do Google Maps no rodapé.
- [x] Validar a composição atualizada em desktop e dispositivos móveis.
- [x] Atualizar a cópia de continuidade no repositório GitHub.
- [x] Substituir os monogramas textuais “AS” pela imagem oficial da marca.
- [x] Validar a leitura das logos substituídas em desktop e mobile.
- [ ] Registrar a revisão visual na cópia de continuidade do GitHub.
