/**
 * Design note — Pórtico de Confiança, redesign premium: arquitetura noir, bordô de assinatura,
 * metal dourado controlado e superfícies grafite. O conteúdo é breve; a imagem, o respiro e o movimento conduzem a leitura.
 */
import { useEffect, useState, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  Facebook,
  Instagram,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  X,
} from "lucide-react";

const assets = {
  logoLight: "/manus-storage/AS_LogoHorizontalFundoClaroPNG_eba9e3cf.png",
  logoDark: "/manus-storage/AS_LogoHorizontalFundoEscuroPNG_7f5c8077.png",
  logoSign: "/manus-storage/AS_LogoSignPNG_557597fa.webp",
  portrait: "/manus-storage/cintia-professional-portrait_15018751.webp",
  hero: "/manus-storage/alcantaro-premium-hero-noir_6e4199cb.png",
  sculpture: "/manus-storage/alcantaro-premium-compliance-sculpture_a71026c3.png",
  context: "/manus-storage/alcantaro-premium-portrait-context_3dae7a6b.png",
};

const navigation = [
  { label: "Atuação", href: "#atuacao" },
  { label: "Visão", href: "#visao" },
  { label: "Fundadora", href: "#fundadora" },
  { label: "Contato", href: "#contato" },
];

const services = [
  {
    number: "01",
    title: "Compliance\ntrabalhista",
    summary: "Estrutura e prevenção para relações de trabalho mais conscientes.",
  },
  {
    number: "02",
    title: "Prevenção\nde passivos",
    summary: "Leitura antecipada dos pontos que pedem atenção.",
  },
  {
    number: "03",
    title: "Advocacia\nfull service",
    summary: "Apoio jurídico integrado ao contexto da empresa.",
  },
];

const whatsappMessage = encodeURIComponent(
  "Olá! Gostaria de iniciar uma conversa com a Alcântaro Soares Advocacia.",
);
const whatsappUrl = `https://wa.me/5511964189875?text=${whatsappMessage}`;
const officeAddress =
  "Rua Henrique Sóter Fernandes, 47, sala 21, Itapecerica de Serra - SP, 06850-710";
const mapsUrl =
  "https://www.google.com/maps/search/?api=1&query=Rua+Henrique+S%C3%B3ter+Fernandes%2C+47%2C+sala+21%2C+Itapecerica+de+Serra+-+SP%2C+06850-710";

function WhatsAppLink({
  children,
  className,
  onClick,
  label,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  label?: string;
}) {
  return (
    <a
      className={className}
      href={whatsappUrl}
      target="_blank"
      rel="noreferrer"
      onClick={onClick}
      aria-label={label}
    >
      {children}
    </a>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    document.documentElement.classList.add("has-motion");
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const revealNodes = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("is-visible");
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -5% 0px" },
    );
    revealNodes.forEach((node) => observer.observe(node));

    return () => {
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className={`topbar ${scrolled ? "topbar--scrolled" : ""}`}>
        <div className="topbar__inner">
          <a className="brand" href="#inicio" aria-label="Alcântaro Soares Advocacia — início">
            <img src={assets.logoDark} alt="Alcântaro Soares Advocacia" />
          </a>

          <nav className="desktop-nav" aria-label="Navegação principal">
            {navigation.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>

          <WhatsAppLink className="topbar__cta">
            <span>Iniciar conversa</span>
            <ArrowUpRight size={16} strokeWidth={1.8} />
          </WhatsAppLink>

          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((current) => !current)}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        <div className={`mobile-nav ${menuOpen ? "mobile-nav--open" : ""}`}>
          <div className="mobile-nav__inner">
            <span className="mobile-nav__caption">Navegação</span>
            {navigation.map((item, index) => (
              <a key={item.href} href={item.href} onClick={closeMenu}>
                <span>0{index + 1}</span>
                {item.label}
                <ArrowUpRight size={18} />
              </a>
            ))}
            <WhatsAppLink className="mobile-nav__cta" onClick={closeMenu}>
              Iniciar uma conversa <MessageCircle size={18} />
            </WhatsAppLink>
          </div>
        </div>
      </header>

      <main>
        <section className="hero" id="inicio" aria-labelledby="hero-title">
          <div className="hero__image" style={{ backgroundImage: `url(${assets.hero})` }} />
          <div className="hero__veil" />
          <div className="hero__noise" />
          <div className="hero__line hero__line--top" aria-hidden="true" />
          <div className="hero__line hero__line--side" aria-hidden="true" />
          <div className="hero__seal" aria-hidden="true">
            <img src={assets.logoSign} alt="" />
          </div>

          <div className="hero__content">
            <p className="eyebrow hero__eyebrow hero-appear">Alcântaro Soares Advocacia</p>
            <h1 id="hero-title" className="hero-appear hero-appear--delay-1">
              Decisões empresariais.<br />
              <em>Leitura jurídica</em><br />
              à altura do contexto.
            </h1>
            <div className="hero__bottom hero-appear hero-appear--delay-2">
              <p>Full service, com especialidade em compliance trabalhista e prevenção de passivos.</p>
              <WhatsAppLink className="button button--gold">
                <span>Iniciar uma conversa</span>
                <ArrowUpRight size={18} strokeWidth={1.8} />
              </WhatsAppLink>
            </div>
          </div>

          <a className="hero__scroll" href="#atuacao" aria-label="Ir para áreas de atuação">
            <span>Conheça a atuação</span>
            <ChevronDown size={17} />
          </a>
        </section>

        <section className="signal-band" aria-label="Síntese de atuação">
          <div className="signal-band__track">
            <span>Advocacia full service</span>
            <i />
            <span>Compliance trabalhista</span>
            <i />
            <span>Prevenção de passivos</span>
            <i />
            <span>Decisão com contexto</span>
          </div>
        </section>

        <section className="services-premium" id="atuacao" aria-labelledby="services-title">
          <div className="services-premium__glow" aria-hidden="true" />
          <div className="section-shell services-premium__inner">
            <div className="section-kicker" data-reveal>
              <span>01</span>
              <i />
              <p>Frentes de atuação</p>
            </div>
            <div className="services-premium__heading" data-reveal>
              <h2 id="services-title">Orientação para o que precisa <em>seguir em movimento.</em></h2>
              <p>Uma leitura jurídica atenta à gestão, às pessoas e ao cenário de cada decisão.</p>
            </div>

            <div className="services-premium__grid">
              <div className="services-premium__visual" data-reveal>
                <img src={assets.sculpture} alt="Composição abstrata em pedra, vidro e metal dourado" />
                <span className="services-premium__visual-label">Estrutura · alinhamento · atenção</span>
              </div>
              <div className="services-premium__list">
                {services.map((service) => (
                  <article className="service-card" key={service.number} data-reveal>
                    <span className="service-card__number">{service.number}</span>
                    <div>
                      <h3>
                        {service.title.split("\n").map((line) => (
                          <span key={line}>{line}</span>
                        ))}
                      </h3>
                      <p>{service.summary}</p>
                    </div>
                    <ArrowDownRight className="service-card__arrow" size={23} strokeWidth={1.35} />
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="vision" id="visao" aria-labelledby="vision-title">
          <div className="vision__image" style={{ backgroundImage: `url(${assets.context})` }} />
          <div className="vision__overlay" />
          <div className="section-shell vision__inner">
            <div className="vision__content" data-reveal>
              <div className="section-kicker section-kicker--light">
                <span>02</span>
                <i />
                <p>O escritório</p>
              </div>
              <h2 id="vision-title">A estratégia começa<br />na qualidade da <em>leitura.</em></h2>
              <p className="vision__lead">Uma conversa que parte do contexto antes de apontar caminhos.</p>
            </div>
            <div className="vision__principles" data-reveal>
              <div><span>01</span><p>Contexto antes da resposta</p></div>
              <div><span>02</span><p>Prevenção como perspectiva</p></div>
              <div><span>03</span><p>Diálogo com a gestão</p></div>
            </div>
          </div>
        </section>

        <section className="founder-premium" id="fundadora" aria-labelledby="founder-title">
          <div className="section-shell founder-premium__inner">
            <div className="founder-premium__portrait" data-reveal>
              <div className="founder-premium__frame" />
              <div className="founder-premium__wash" aria-hidden="true" />
              <img src={assets.portrait} alt="Retrato profissional de Cintia Alves Soares" />
              <div className="founder-premium__portrait-mark" aria-hidden="true"><img src={assets.logoSign} alt="" /></div>
            </div>
            <div className="founder-premium__copy" data-reveal>
              <div className="section-kicker">
                <span>03</span>
                <i />
                <p>Fundadora</p>
              </div>
              <h2 id="founder-title">Cintia Alves Soares<em> fundadora e CEO.</em></h2>
              <p>Advocacia empresarial, relações trabalhistas e gestão de riscos.</p>
              <a
                className="text-link"
                href="https://www.linkedin.com/in/cintia-soares-581898a3/"
                target="_blank"
                rel="noreferrer"
              >
                Ver perfil profissional <ArrowUpRight size={18} />
              </a>
              <div className="founder-premium__brand-plaque" aria-hidden="true">
                <span>03</span>
                <img src={assets.logoSign} alt="" />
              </div>
            </div>
          </div>
        </section>

        <section className="contact-premium" id="contato" aria-labelledby="contact-title">
          <div className="contact-premium__halo" aria-hidden="true" />
          <div className="section-shell contact-premium__inner">
            <div className="contact-premium__mark" data-reveal>
              <img src={assets.logoSign} alt="Alcântaro Soares Advocacia" />
            </div>
            <div className="contact-premium__content" data-reveal>
              <p className="eyebrow">Comece uma conversa</p>
              <h2 id="contact-title">Seu contexto merece uma leitura <em>atenta.</em></h2>
              <p>Apresente o cenário e indique o melhor caminho para iniciar a conversa.</p>
            </div>
            <div className="contact-premium__actions" data-reveal>
              <WhatsAppLink className="button button--light">
                <MessageCircle size={19} />
                <span>WhatsApp</span>
                <ArrowUpRight size={19} />
              </WhatsAppLink>
              <a className="contact-premium__email" href="mailto:contat@alcantarosoaresadv.com.br">
                <Mail size={18} /> contat@alcantarosoaresadv.com.br
              </a>
            </div>
          </div>
        </section>
      </main>

      <WhatsAppLink
        className="whatsapp-float"
        label="Iniciar uma conversa com a Alcântaro Soares Advocacia pelo WhatsApp"
      >
        <MessageCircle size={25} strokeWidth={2} />
      </WhatsAppLink>

      <footer className="footer-premium">
        <div className="section-shell footer-premium__inner">
          <div className="footer-premium__upper">
            <img className="footer-premium__logo" src={assets.logoDark} alt="Alcântaro Soares Advocacia" />
            <nav aria-label="Navegação do rodapé">
              {navigation.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}
            </nav>
            <div className="footer-premium__socials" aria-label="Redes sociais">
              <a href="https://www.instagram.com/alcantaro.soares.advocacia/" target="_blank" rel="noreferrer" aria-label="Instagram da Alcântaro Soares Advocacia"><Instagram size={18} /></a>
              <a href="https://www.facebook.com/61591049637249" target="_blank" rel="noreferrer" aria-label="Facebook da Alcântaro Soares Advocacia"><Facebook size={18} /></a>
            </div>
          </div>
          <div className="footer-premium__address">
            <span>Endereço</span>
            <a href={mapsUrl} target="_blank" rel="noreferrer" aria-label="Abrir endereço no Google Maps">
              <MapPin size={17} />
              <span>{officeAddress}</span>
              <ArrowUpRight size={16} />
            </a>
          </div>
          <div className="footer-premium__lower">
            <span>© {new Date().getFullYear()} Alcântaro Soares Advocacia.</span>
            <span>Advocacia empresarial · Compliance trabalhista</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
