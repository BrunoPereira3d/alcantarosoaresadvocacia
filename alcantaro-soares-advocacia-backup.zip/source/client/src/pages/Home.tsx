/**
 * Design note — Pórtico de Confiança: uma narrativa assimétrica de bordô, dourado e
 * off-white. A página privilegia leitura, contraste material e decisões empresariais.
 */
import { useEffect, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  Facebook,
  Instagram,
  Mail,
  Menu,
  MessageCircle,
  X,
} from "lucide-react";

const assets = {
  logoLight: "/manus-storage/AS_LogoHorizontalFundoClaroPNG_eba9e3cf.png",
  logoDark: "/manus-storage/AS_LogoHorizontalFundoEscuroPNG_7f5c8077.png",
  logoSign: "/manus-storage/AS_LogoSignPNG_557597fa.webp",
  portrait: "/manus-storage/cintia-professional-portrait_15018751.webp",
  hero: "/manus-storage/alcantaro-hero-institucional_dce878bc.png",
  texture: "/manus-storage/alcantaro-textura-marble_8248d1c3.png",
};

const navigation = [
  { label: "Atuação", href: "#atuacao" },
  { label: "O escritório", href: "#escritorio" },
  { label: "Fundadora", href: "#fundadora" },
];

const services = [
  {
    index: "01",
    title: "Compliance trabalhista",
    text: "Estruturação de práticas e rotinas jurídicas para apoiar decisões empresariais no campo das relações de trabalho.",
    accent: "Foco especial",
  },
  {
    index: "02",
    title: "Prevenção de passivos",
    text: "Leitura preventiva de cenários para dar visibilidade a pontos de atenção antes que eles ganhem proporção.",
    accent: "Atuação estratégica",
  },
  {
    index: "03",
    title: "Advocacia full service",
    text: "Apoio jurídico empresarial com uma visão integrada do contexto, das pessoas envolvidas e das decisões a seguir.",
    accent: "Visão integrada",
  },
];

function WhatsAppLink({
  children,
  className,
  onClick,
}: {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <a
      className={className}
      href="https://wa.me/5511964189875"
      target="_blank"
      rel="noreferrer"
      onClick={onClick}
    >
      {children}
    </a>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 28);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className={`topbar ${scrolled ? "topbar--scrolled" : ""}`}>
        <div className="topbar__inner">
          <a className="brand" href="#inicio" aria-label="Alcântaro Soares Advocacia — início">
            <img src={assets.logoDark} alt="Alcântaro Soares Advocacia" />
          </a>

          <nav className="desktop-nav" aria-label="Navegação principal">
            {navigation.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>

          <WhatsAppLink className="topbar__cta">
            <span>Falar com o escritório</span>
            <ArrowUpRight size={16} strokeWidth={1.8} />
          </WhatsAppLink>

          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((current) => !current)}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        <div className={`mobile-nav ${menuOpen ? "mobile-nav--open" : ""}`}>
          <div className="mobile-nav__links">
            {navigation.map((item, index) => (
              <a key={item.href} href={item.href} onClick={closeMenu}>
                <span>0{index + 1}</span>
                {item.label}
                <ArrowUpRight size={18} />
              </a>
            ))}
          </div>
          <WhatsAppLink className="mobile-nav__cta" onClick={closeMenu}>
            Iniciar uma conversa <MessageCircle size={18} />
          </WhatsAppLink>
        </div>
      </header>

      <main>
        <section className="hero" id="inicio" aria-labelledby="hero-title">
          <div className="hero__image" style={{ backgroundImage: `url(${assets.hero})` }} />
          <div className="hero__veil" />
          <div className="hero__grain" />
          <div className="hero__frame" aria-hidden="true" />
          <div className="hero__thread" aria-hidden="true"><span /></div>

          <div className="hero__inner">
            <div className="eyebrow hero__eyebrow">
              <span className="eyebrow__line" />
              Alcântaro Soares Advocacia
            </div>
            <h1 id="hero-title">
              Decisões empresariais
              <em> pedem leitura jurídica</em>
              <span> à altura do contexto.</span>
            </h1>
            <div className="hero__lower">
              <p>
                Advocacia full service, com olhar especial para compliance trabalhista e prevenção de
                passivos da área.
              </p>
              <WhatsAppLink className="button button--gold">
                <span>Iniciar uma conversa</span>
                <ArrowUpRight size={19} strokeWidth={1.75} />
              </WhatsAppLink>
            </div>
          </div>

          <a className="hero__scroll" href="#atuacao" aria-label="Ir para atuação">
            <span>Conheça a atuação</span>
            <ChevronDown size={18} />
          </a>
        </section>

        <section className="signal-band" aria-label="Áreas de atuação">
          <div className="signal-band__track">
            <span>Advocacia full service</span>
            <i />
            <span>Compliance trabalhista</span>
            <i />
            <span>Prevenção de passivos</span>
            <i />
            <span>Gestão inteligente</span>
            <i />
            <span>Conformidade técnica</span>
          </div>
        </section>

        <section className="services section-padding" id="atuacao" aria-labelledby="services-title">
          <div className="chapter-rail" aria-hidden="true"><span /></div>
          <div className="section-guide">
            <span className="section-guide__number">01</span>
            <span className="section-guide__line" />
            <span>Frentes de atuação</span>
          </div>

          <div className="services__intro">
            <div>
              <p className="eyebrow eyebrow--dark">Atuação orientada por contexto</p>
              <h2 id="services-title">
                Uma estrutura jurídica que acompanha <em>as decisões que movem o negócio.</em>
              </h2>
            </div>
            <p className="services__intro-copy">
              O trabalho parte de uma leitura atenta do cenário empresarial, com especialidade em
              compliance trabalhista e na prevenção de passivos da área.
            </p>
          </div>

          <div className="services__layout">
            <aside className="services__aside">
              <span className="services__aside-mark">AS</span>
              <p>Uma atuação que articula prevenção, conformidade e gestão.</p>
              <span className="services__aside-rule" />
              <span className="services__aside-caption">Capítulos de atuação</span>
            </aside>

            <div className="services__list">
              {services.map((service) => (
                <article className="service-row" key={service.index}>
                  <div className="service-row__index">{service.index}</div>
                  <div className="service-row__content">
                    <p className="service-row__accent">{service.accent}</p>
                    <h3>{service.title}</h3>
                    <p>{service.text}</p>
                  </div>
                  <div className="service-row__arrow" aria-hidden="true">
                    <ArrowDownRight size={22} strokeWidth={1.25} />
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="approach" id="escritorio" aria-labelledby="approach-title">
          <div className="chapter-rail chapter-rail--light" aria-hidden="true"><span /></div>
          <div className="approach__texture" style={{ backgroundImage: `url(${assets.texture})` }} />
          <div className="approach__overlay" />
          <div className="approach__inner section-padding">
            <div className="section-guide section-guide--light">
              <span className="section-guide__number">02</span>
              <span className="section-guide__line" />
              <span>Como orientamos a conversa</span>
            </div>
            <div className="approach__content">
              <div className="approach__heading">
                <p className="eyebrow">O escritório</p>
                <h2 id="approach-title">
                  Estratégia jurídica começa pela qualidade da <em>leitura do cenário.</em>
                </h2>
              </div>

              <div className="approach__principles">
                <article>
                  <span>01</span>
                  <h3>Contexto antes da resposta</h3>
                  <p>
                    Cada conversa é uma oportunidade para compreender o que está em jogo antes de
                    apontar caminhos.
                  </p>
                </article>
                <article>
                  <span>02</span>
                  <h3>Prevenção como perspectiva</h3>
                  <p>
                    A especialidade em compliance trabalhista orienta uma visão que antecipa pontos
                    de atenção.
                  </p>
                </article>
                <article>
                  <span>03</span>
                  <h3>Diálogo com a gestão</h3>
                  <p>
                    A atuação se aproxima de empresas, gestores e profissionais de RH em seus
                    contextos de decisão.
                  </p>
                </article>
              </div>
            </div>
          </div>
        </section>

        <section className="founder section-padding" id="fundadora" aria-labelledby="founder-title">
          <div className="chapter-rail" aria-hidden="true"><span /></div>
          <div className="section-guide">
            <span className="section-guide__number">03</span>
            <span className="section-guide__line" />
            <span>Fundadora</span>
          </div>
          <div className="founder__layout">
            <div className="founder__copy">
              <p className="eyebrow eyebrow--dark">Alcântaro Soares Advocacia</p>
              <h2 id="founder-title">
                Cintia Alves Soares<em> é fundadora e CEO do escritório.</em>
              </h2>
              <p className="founder__summary">
                Sua atuação pública reúne advocacia empresarial, direito do trabalho, compliance
                trabalhista, relações trabalhistas, gestão de riscos, business partner e recursos
                humanos.
              </p>
              <div className="founder__tags" aria-label="Temas de atuação apresentados publicamente">
                <span>Advocacia empresarial</span>
                <span>Direito do trabalho</span>
                <span>Compliance trabalhista</span>
                <span>Gestão de riscos</span>
              </div>
              <a
                className="text-link"
                href="https://www.linkedin.com/in/cintia-soares-581898a3/"
                target="_blank"
                rel="noreferrer"
              >
                Ver perfil profissional <ArrowUpRight size={18} />
              </a>
            </div>

            <figure className="founder__portrait">
              <div className="founder__portrait-frame" />
              <img src={assets.portrait} alt="Retrato profissional de Cintia Alves Soares" />
              <figcaption>
                <span>AS</span>
                <span>Fundadora e CEO</span>
              </figcaption>
            </figure>
          </div>
        </section>

        <section className="contact" id="contato" aria-labelledby="contact-title">
          <div className="chapter-rail chapter-rail--light" aria-hidden="true"><span /></div>
          <div className="contact__inner">
            <div className="contact__monogram" aria-hidden="true">
              <img src={assets.logoSign} alt="" />
            </div>
            <div className="contact__content">
              <p className="eyebrow">Comece uma conversa</p>
              <h2 id="contact-title">
                Seu contexto merece uma leitura <em>atenta.</em>
              </h2>
              <p>
                Entre em contato para apresentar o cenário e indicar o melhor caminho para iniciar
                a conversa.
              </p>
            </div>
            <div className="contact__actions">
              <WhatsAppLink className="button button--light">
                <MessageCircle size={19} />
                <span>WhatsApp</span>
                <ArrowUpRight size={19} />
              </WhatsAppLink>
              <a className="contact__email" href="mailto:contat@alcantarosoaresadv.com.br">
                <Mail size={18} />
                <span>contat@alcantarosoaresadv.com.br</span>
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer__upper">
          <img className="footer__logo" src={assets.logoLight} alt="Alcântaro Soares Advocacia" />
          <div className="footer__links">
            <a href="#atuacao">Atuação</a>
            <a href="#escritorio">O escritório</a>
            <a href="#fundadora">Fundadora</a>
            <a href="#contato">Contato</a>
          </div>
          <div className="footer__socials" aria-label="Redes sociais">
            <a
              href="https://www.instagram.com/alcantaro.soares.advocacia/"
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram da Alcântaro Soares Advocacia"
            >
              <Instagram size={19} />
            </a>
            <a
              href="https://www.facebook.com/61591049637249"
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook da Alcântaro Soares Advocacia"
            >
              <Facebook size={19} />
            </a>
          </div>
        </div>
        <div className="footer__lower">
          <span>© {new Date().getFullYear()} Alcântaro Soares Advocacia.</span>
          <span>Advocacia empresarial · Compliance trabalhista · Prevenção de passivos</span>
        </div>
      </footer>
    </div>
  );
}
