# Pendências de reconstrução

- [ ] Verificar informações públicas dos perfis oficiais e registrar somente dados confirmados.
- [ ] Preparar e hospedar os logotipos, retrato e imagens fornecidas como assets estáticos do projeto.
- [ ] Elaborar textos institucionais sem alegações, resultados ou informações não confirmadas.
- [ ] Implementar a página institucional responsiva, incluindo SEO e prévia de compartilhamento.
- [ ] Validar conteúdo, experiência visual e acessibilidade em desktop e mobile.
- [ ] Criar ou atualizar o repositório GitHub `alcantarosoaresadvocacia` com o código final e verificar o envio.
